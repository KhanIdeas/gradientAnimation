//
//  ViewController.swift
//  customview
//
//  Created by Ishkhan Gevorgyan on 11/26/17.
//  Copyright © 2017 Ishkhan Gevorgyan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
     let layer1 = CAShapeLayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        var path: UIBezierPath!
       
        path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: self.view.frame.height))
        path.addLine(to: CGPoint(x: 0, y: self.view.frame.size.height/2 ))
        path.addLine(to: CGPoint(x: self.view.frame.size.width, y: self.view.frame.size.height/2 + 100))
        path.addLine(to: CGPoint(x: self.view.frame.size.width, y: self.view.frame.size.height))
        path.close()
        
        layer1.path = path.cgPath
        layer1.fillColor = UIColor.red.cgColor
        view.layer.addSublayer(layer1)
        
        let gradient = CAGradientLayer()
        gradient.frame = self.view.frame
        gradient.colors = [UIColor.red.cgColor,
                           UIColor.green.cgColor]
        gradient.startPoint = CGPoint(x: 0, y: 0.8)
        gradient.endPoint = CGPoint(x: 0.1, y: 0.4)
        
        view.layer.addSublayer(gradient)
        gradient.mask = layer1
       // layer.mask = gradient
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }

    @IBAction func transform(_ sender: Any) {
        var newPoints = [CGPoint]()
        
        newPoints.append(CGPoint(x: 0, y: 200))
        newPoints.append(CGPoint(x: self.view.frame.size.width, y: 230))
        newPoints.append(CGPoint(x: self.view.frame.size.width, y: self.view.frame.size.height))
        newPoints.append(CGPoint(x: 0, y: self.view.frame.size.height))
        
        let animation = CABasicAnimation(keyPath: "path")
        animation.toValue = newPoints.path // Convert our new points array to a CGPathRef
        
        // Set the animation duration and specify we want it to return to its
        // starting shape.
        animation.duration = 2.0
        animation.autoreverses = true
        layer1.add(animation, forKey: "path")
    }
    
}
protocol Pointable {
    var point:CGPoint { get }
}

extension CGPoint: Pointable {
    var point : CGPoint {
        get {
            return self
        }
    }
}
extension Array where Element : Pointable {
    var path : CGPath {
        let bezier = UIBezierPath()
        
        if self.count > 0 {
            bezier.move(to: self[0].point)
        }
        
        var i:Int = 0
        repeat {
            bezier.addLine(to: self[i].point)
            i += 1
        } while i < self.count
        
        bezier.close()
        
        return bezier.cgPath
        
    }
}




